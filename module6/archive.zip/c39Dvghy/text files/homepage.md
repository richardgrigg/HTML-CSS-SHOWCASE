# The only marketing agency on a mission from God, fully dedicated to increase your web traffic. 

We’re two brothers from Chicago that are trying to pay back our debt. We can help you with SEO, SEM content marketing and whatever else.

##About Us

We grew up in downtown Chicago, and we used to play in a band. Jake loves fried chicken, and Elwood loves dry white toast.

## Our skills

Elwood is an expert in SEO, SEM, and driving from the police. Jake is our social media specialist, and he has an amazing voice.

## Get in touch

Send us an email with some info about what help you need and we’ll drive over to your place in our Bluesmobile the following day to discuss the deal.